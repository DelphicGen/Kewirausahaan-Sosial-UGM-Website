let baseUrl = '/';

module.exports = baseUrl