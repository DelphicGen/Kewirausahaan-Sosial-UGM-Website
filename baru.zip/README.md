# Kewirausahaan-Sosial-UGM-Website
Dinamic Website using node js, ejs and mysql